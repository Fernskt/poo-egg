/*
 Los métodos de la interfaz los podemos implementar en nuestra clase y se van a sobrescribir
desde la interfaz, métodos que recordemos, no tendrán cuerpo. Nuestra tarea será completar
esos métodos que implementamos de la interfaz.
 */
package Interfaces;

/**
 *
 * @author Pc
 */
public interface NewInterface {
    
    public void hacerMuertito();
    
    
}
